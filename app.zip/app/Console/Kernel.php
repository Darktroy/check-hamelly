<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
                Commands\quaterhour::class,

    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        /*
        $schedule->call('App\Http\Controllers\Api\RiderController@cron_request_car')->everyMinute();
        $schedule->call('App\Http\Controllers\HomeController@currency_cron')->daily();
        // $schedule->command('inspire')
        //          ->hourly();
        $schedule->command('queue:work --tries=3 --once')->cron('* * * * * *');*/
        $schedule->command('qhour')->everyMinute();
    }

    /**
     * Register the Closure based commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        
        $this->load(__DIR__.'/Commands');
        require base_path('routes/console.php');
    }
}
