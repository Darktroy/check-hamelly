<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class reset_password extends Model
{
    //
}
