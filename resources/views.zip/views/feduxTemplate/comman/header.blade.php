<!DOCTYPE html>
<html>
    
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>hamelly</title>
        <meta name="description" content="An interactive getting started guide for Brackets.">
        {!! Html::style('newDesign/css/bootstrap.css') !!}
        {!! Html::style('newDesign/css/font-awesome.min.css') !!}
        {!! Html::style('newDesign/css/style.css') !!}
        <!--[if lt IE 9]>
        <script src="js/html5shiv.min.js"></script>
        <script src="js/respond.min.js"></script>
        <![endif]-->
        
    </head>
    <body>
        <!-- start wrapper-->
        <div class="wrapper">