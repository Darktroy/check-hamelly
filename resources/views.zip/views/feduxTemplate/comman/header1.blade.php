<!-- start header1 -->
            <div class="header1">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-7">
                            <div class="icons">
                                
                                <p><img src="{{ url('newDesign/img/email.png')}}" title="email"></i>hamelly@gmail.com</p>
                                <p><img src="{{ url('newDesign/img/phone.png')}}" title="phone">056666463-056666738</p>
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div class="icons icons2">
                                <div class="dropdown">
                                  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">
                                      <img src="{{ url('newDesign/img/en.png')}}" title="lang">English
                                  <span class="caret"></span></button>
                                  <ul class="dropdown-menu">
                                    <li><a href="#">link 1</a></li>
                                    <li><a href="#">link 2</a></li>
                                    <li><a href="#">link 3</a></li>
                                  </ul>
                                </div>
                                <div class="dropdown">
                                  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">
                                      Sign in
                                  <span class="caret"></span></button>
                                  <ul class="dropdown-menu">
                                    <li><a href="{{url('signin_company')}}">Organization</a></li>
                                    <li><a href="#">link 2</a></li>
                                    <li><a href="#">link 3</a></li>
                                  </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end header1 -->