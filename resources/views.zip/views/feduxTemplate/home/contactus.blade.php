@extends('feduxTemplate.mainTemplate')
@section('main')
            <div class="clearfix"></div>
            <!-- start page title -->
            <div class="page-title">
                <div class="container">
                    <div class="row">
                        <h3>Contact</h3>
                    </div>
                </div>
            </div>
            <!-- end page title -->
            <!-- start internal page -->
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="contact-details">
                            <div class="details-text m-0">
                                <span></span>
                                <p class="bold">KEEP IN TOUCH</p>
                            </div>
                            <p class="text2">We finally got a piece of the pie. As long as we live its you and me baby. There ain't nothin' wrong with that love exciting and new come. Love life's sweetest reward Let it flow it floats back to you. These Happy Days are yours and mine Happy Days. You wanna be where you can see our troubles are all the same.</p>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="contact-details">
                            <div class="details-text m-0">
                                <span></span>
                                <p class="bold">QUICK CONTACT</p>
                            </div>
                            <div class="details">
                                <div class="details-icon">
                                    <img src="{{url('newDesign/img/contact1.png')}}"> 
                                </div>
                                <div class="details-text">
                                    <p class="details-text1">Office</p>
                                    <p class="details-text2">+1 (987) 6543 20, +1 (234) 5678 09</p>
                                </div>
                            </div>
                            <div class="details">
                                <div class="details-icon">
                                    <img src="{{url('newDesign/img/contact2.png')}}"> 
                                </div>
                                <div class="details-text">
                                    <p class="details-text1">Customer Service</p>
                                    <p class="details-text2">1800 11 223 4567, 1800 99 887</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end internal page -->
            <!-- start contact form -->
<!--            <div class="section grey">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 text-center">
                            <div class="details-text details-text3 mb-25">
                                <span></span>
                                <p class="bold">LEAVE A MESSAGE</p>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <form>
                                  <div class="form-group col-sm-6 mb-25">
                                    <input type="text" class="form-control form-control2" placeholder="Name">
                                  </div>
                                  <div class="form-group col-sm-6 mb-25">
                                    <input type="text" class="form-control form-control2" placeholder="Email">
                                  </div>
                                  <div class="form-group col-sm-6 mb-25">
                                    <input type="text" class="form-control form-control2" placeholder="Your phone number">
                                  </div>
                                  <div class="form-group col-sm-6 mb-25">
                                    <input type="text" class="form-control form-control2" placeholder="subject">
                                  </div>
                                  <div class="form-group col-sm-12 mb-25">
                                    <textarea class="form-control form-control2" placeholder="Message if any"></textarea>
                                  </div>
                                  <div class="form-group col-sm-12 text-center">
                                      <button type="submit" class="btn the-btn4">Submit</button>
                                  </div>
                            </form> 
                        </div>
                    </div>
                </div>
            </div>-->
            <!-- end contact form -->
@stop