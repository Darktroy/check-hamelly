
@include('feduxTemplate.comman.header')
@include('feduxTemplate.comman.header1')
@include('feduxTemplate.comman.header2')


@yield('main')



@include('feduxTemplate.comman.footer')