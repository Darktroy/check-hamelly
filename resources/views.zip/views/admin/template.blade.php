@include('admin.common.head')

@include('admin.common.header')


@include('admin.common.navigation')


@yield('main')

@include('admin.common.footer')

@include('admin.common.foot')