@include('common.head')
@include('common.header')



@yield('main')



@include('common.footer')
@include('common.footWithoutAngular')