<div class="msg">
<u></u>

<div bgcolor="#EEEEEE" style="margin:0;padding:0;font-family:&quot;Helvetica Neue&quot;,&quot;Helvetica&quot;,Helvetica,Arial,sans-serif;color:#565a5c;min-height:100%;background-color:#f7f7f7;font-size:16px;line-height:150%;width:100%!important">

<div style="margin:0;padding:0;font-family:&quot;Helvetica Neue&quot;,&quot;Helvetica&quot;,Helvetica,Arial,sans-serif;width:0;min-height:0;color:transparent;display:none!important">
</div>

<table style="margin:0;padding:0;font-family:&quot;Helvetica Neue&quot;,&quot;Helvetica&quot;,Helvetica,Arial,sans-serif;line-height:150%;border-spacing:0;background-color:#f7f7f7;width:100%">
<tbody>
<tr style="margin:0;padding:0;font-family:&quot;Helvetica Neue&quot;,&quot;Helvetica&quot;,Helvetica,Arial,sans-serif">
<td style="margin:0;padding:0;font-family:&quot;Helvetica Neue&quot;,&quot;Helvetica&quot;,Helvetica,Arial,sans-serif"></td>
<td style="padding:0;font-family:&quot;Helvetica Neue&quot;,&quot;Helvetica&quot;,Helvetica,Arial,sans-serif;display:block!important;margin:0 auto!important;clear:both!important;max-width:610px!important">

<div style="font-family:&quot;Helvetica Neue&quot;,&quot;Helvetica&quot;,Helvetica,Arial,sans-serif;padding:15px;max-width:600px;display:block;margin:0 auto;padding-left:5px;padding-right:5px;padding-bottom:5px;padding-top:0px">

<div style="margin:0;padding:0;font-family:&quot;Helvetica Neue&quot;,&quot;Helvetica&quot;,Helvetica,Arial,sans-serif">

<table border="0" cellpadding="0" cellspacing="0" style="border:none;border-collapse:collapse;border-spacing:0;max-width:700px;width:100%">
  <tbody><tr>
    <td bgcolor="#62CEAD" valign="bottom" background="{{ url('images/email_background.jpg')}}" style="background-size:cover;background-image:url('images/email_background.jpg')" align="center">
      
          <div>
            <table border="0" cellpadding="0" cellspacing="0" style="border:none;border-collapse:collapse;border-spacing:0;width:100%">
              <tbody><tr>
                <td style="padding:0;margin:0;width:81%" align="center"></td>
                <td style="padding:0;margin:0;width:13%" align="center" valign="bottom"><img src="{{ url('images/email_background.jpg')}}" width="96" height="" border="0" class="m_8700322356242046330bitTop CToWUd" style="clear:both;display:block;height:auto;max-height:60px;max-width:96px;min-width:65px;outline:none;text-decoration:none;width:100%"></td>
                <td style="padding:0;margin:0;width:6%;min-width:15px" align="center"></td>
              </tr>
              </tbody>
            </table>
          </div>
          
    </td>
  </tr>
</tbody></table>
<table border="0" cellpadding="0" cellspacing="0" style="border:none;border-collapse:collapse;border-spacing:0;margin:0 auto;max-width:700px;width:100%">
  <tbody><tr>
    <td style="padding:0;margin:0;background-color:#ffffff" align="center">
      <table border="0" cellpadding="0" cellspacing="0" style="border:none;border-collapse:collapse;border-spacing:0;width:100%">
        <tbody><tr>
          <td style="padding:0;margin:0;width:81%" align="center"></td>
          <td style="padding:0;margin:0;width:13%" align="center">
            <table border="0" cellpadding="0" cellspacing="0" style="border:none;border-collapse:collapse;border-spacing:0;width:100%">
              <tbody><tr>
                <td style="background-color:#000000"><img src="{{ url('images/logo.png')}}" width="96" height="" border="0" class=" " style="clear:both;display:block;height:auto;max-height:90px;max-width:96px;min-width:65px;outline:none;text-decoration:none;width:100%"></td>
              </tr>
            </tbody></table>
          </td>
          <td style="padding:0;margin:0;width:6%;min-width:15px" align="center"></td>
        </tr>
      </tbody></table>
    </td>
  </tr>
</tbody></table>



