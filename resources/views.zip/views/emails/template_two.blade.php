@include('emails.common.header')

@yield('emails.main')

@include('emails.common.footer')