@include('common.head')
@include('common.dashboard_header')


@include('common.dashboard_side_menu')
@yield('main')



@include('common.footer')
@include('common.foot')