<main style="text-align: center" id="site-content" role="main">
<img src="{{ url('images/logos/logo.png') }}" style="height: 100px;width:100px">
<div class="page-container-responsive" style="min-height: 485px">
  <div class="row row-space-top-8 row-space-8">
    <div class="col-md-12 text-center">
      <h1 class="text-jumbo text-ginormous hide-sm">{{trans('messages.errors.oops')}}</h1>
      <h4>{{trans('messages.errors.cannot_find')}}</h4>
    </div>
  </div>
</div>
</main>