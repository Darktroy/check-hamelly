<!-- <div class="container-fluid page-footer-back" style="padding: 0">
	<div class="footer-img1  footercontent"><img src="{{url('images/icon/footer2_2.png')}}"></div>
</div> -->

<footer class="container-fluid" style="background:#000;">
</div>
</div>
</div>
</footer>
<style type="text/css">
	footer .nav-list-one li {
		padding-bottom: 5px;
	}
	#top-city-footer li {
		display: inline-block;
		padding-right: 15px;
	}
	#top-city-footer li a {
		font-size: 13px !important;
	}
</style>