@include('common.head')

@yield('main')

@include('common.foot')